
#include <project.h>
#include "data.h"

void lcd_init();
void lcd_test_print();
void lcd_print_bms();
void lcd_print(char* string);